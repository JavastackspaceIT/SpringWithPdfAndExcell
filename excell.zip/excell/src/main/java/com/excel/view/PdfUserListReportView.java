package com.excel.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.excel.model.User;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;

public class PdfUserListReportView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		response.setHeader("Content-Disposition", "attachment; filename=\"user_list.pdf\"");
        System.out.println("setHeader");
		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) model.get("userlist");
         System.out.println("List Data :"+list);
		Table table = new Table(4);
		table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		table.addCell("ID");
		table.addCell("USERNAME");
		table.addCell("FIRST NAME");
		table.addCell("LAST NAME");
System.out.println("table row added"+table.toString());
		for (User user : list) {
			table.addCell(String.valueOf(user.getId()));
			table.addCell(user.getUsername());
			table.addCell(user.getFirstname());
			table.addCell(user.getLastname());
			
		}
		System.out.println("user list2"+list);

		document.add(table);
	}
}